from setuptools import setup, find_packages

setup(
    name='cashiercounter',
    version='0.0.1',
    author='Lavanya Emart',
    author_email='support@lavanya.com',
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    install_requires=[],
)
