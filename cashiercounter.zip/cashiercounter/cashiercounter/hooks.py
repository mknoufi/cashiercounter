app_name = "cashiercounter"
app_title = "Cashier Counter"
app_publisher = "Your Company or Name"
app_description = "Custom dashboard for cashier collection reporting"
app_email = "your@email.com"
app_license = "MIT"

# Optional: If you have general JS/CSS in public folders to include in Desk UI
# Commented out as not needed in your current setup
# app_include_js = "/assets/cashiercounter/js/cashier_collection_dashboard.js"
# app_include_css = "/assets/cashiercounter/css/custom.css"

# Do not include website-related assets, since `www/` is deleted
# website_include_js = []
# website_include_css = []

# No web templates or portal hooks in current scope

# Fixtures (optional): Include if you export custom roles, permissions, fields
# fixtures = ["Custom Field", "Property Setter"]