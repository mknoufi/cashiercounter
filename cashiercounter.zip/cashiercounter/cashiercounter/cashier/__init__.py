# Good
# cashier/__init__.py