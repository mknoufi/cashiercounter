from frappe import _

def get_data():
    return [
        {
            "module_name": "Cashier",
            "type": "module",
            "label": _("Cashier"),
            "icon": "octicon octicon-briefcase",
            "color": "blue"
        }
    ]