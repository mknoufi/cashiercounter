"""
Configuration for docs
"""
